# -*- coding: utf-8 -*-
"""
Created on Wed Aug 28 16:07:07 2019

@author: MooreN
"""

# this program asks for the user's name

print('Hello You!')

print('What is your name?')
myName = input()
print('It is good to meet you ' + myName)
print('Your name has ' + str(len(myName)) + ' letters')

print('What is your age?')
myAge = input()
print('You will be ' + str(int(myAge) + 1) + ' in a year')

name = input()
age = int(input())
