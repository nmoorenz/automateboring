# -*- coding: utf-8 -*-
"""
Created on Mon Oct  7 11:45:08 2019

@author: MooreN
"""

"""
1. 
Operators and values
*
-
/
+

'hello'
-88.8
5
"""
"""
2. 
Variable and string
spam

'spam'
"""
"""
3. 
name three data types
string
float
integer
boolean
None
"""
"""
4. 
What is an expression made of? What do all expressions do? 

values, operators, evaluate down to one value
"""
"""
5. 
Assignment statements: spam = 10
What is the difference between expression and assignment? 

Expressions are evaluated, assignments are evaluated then stored
"""
"""
6. 
what does bacon contain after this? 
bacon = 20
bacon + 1

bacon still contains 20
"""
""" 
7.
What would the following evaluate to? 
'spam' + 'spamspam'
'spam' * 3

both evaluate to 'spamspamspam'
"""
"""
8.
eggs is valid variable name, 100 is not

variables must start with a character or underscore
"""
"""
9.
integer, floating point, string versions of a value

int(), float(), str()
"""
""" 
10.
why does this cause an error? fix it
'I have eaten ' + 99 + ' burritos'

str(99) or '99' needs to be a string as well
"""













