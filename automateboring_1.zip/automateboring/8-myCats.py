cats = [{'desc': 'chubby', 'name': 'Sophie'}, {'desc': 'cute', 'name': 'Panda'}]
